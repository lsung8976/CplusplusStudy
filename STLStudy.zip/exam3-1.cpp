#include <iostream>
using namespace std;

void Print()
{
cout << "�����Լ�!" << endl;
}

struct Functor
{
	void operator()()
	{
		cout << "�Լ� ��ü!" << endl;
	}
};

int main()
{
	Functor functor;

	Print();
	functor();

	return 0;
}