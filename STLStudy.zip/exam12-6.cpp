#include <iostream>
#include <string>
using namespace std;

int main()
{
	string s("Hello!");
	string buf[100];

	s.copy(buf, s.length());
}