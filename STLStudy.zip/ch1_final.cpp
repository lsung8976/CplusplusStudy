#include <iostream>
#include <cstring>
using namespace std;

class String
{
private:
	char* ptr;
	int size;
public:
	String(const char* str)
	{
		size = strlen(str) + 1;
		ptr = new char[size];
		strcpy_s(ptr, size, str)
			
			;
	}
	String(const String& str)
	{
		delete[] ptr;
		size = str.size;
		ptr = new char[size];
		strcpy_s(ptr, size, str.ptr);
	}
	void Print() const
	{
		cout << ptr << endl;
	}
	operator const char*() const
	{
		return ptr;
	}
	/*String& operator=(String& str)
	{
		delete[] ptr;
		size = str.size;
		ptr = new char[size];
		strcpy_s(ptr, size, str.ptr);
	}*/
	/*String& operator=(const char* str)
	{
		delete[] ptr;
		size = strlen(str) + 1;
		ptr = new char[size];
		strcpy_s(ptr, size, str);
		return *this;
	}*/
	~String()
	{
		delete[] ptr;
	}
};

int main()
{
	/*
	String s("Hello!");
	s.Print();
	const char* sz = s;
	cout << sz << endl;
	*/
	
	const char* sz = "Hello!";
	String s("Hi~");
	s = sz;
	s.Print();
	
}
