#include <iostream>
#include <functional>
using namespace std;

int main()
{
	binder1st<less<int>> binder = bind1st(less<int>(), 10);

	cout << binder(5) << " : " << less<int>()(10, 5) << endl;

	cout << binder(10) << " : " << less<int>()(10, 10) << endl;

	cout << binder(20) << " : " << less<int>()(10, 20) << endl;

	cout << "==���� ����==" << endl;

	cout << bind1st(less<int>(), 10)(5) << " : " << less<int>()(10, 5) << endl;

	cout << bind1st(less<int>(), 10)(10) << " : " << less<int>()(10, 10) << endl;

	cout << bind1st(less<int>(), 10)(20) << " : " << less<int>()(10, 20) << endl;

	return 0;
}// ���δ�