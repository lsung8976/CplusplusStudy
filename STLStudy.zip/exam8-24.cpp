#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

bool Pred(int left, int right)
{
	return abs(left - right) <= 5;
}

int main()
{
	vector<int> v1;
	v1.push_back(10);
	v1.push_back(20);
	v1.push_back(32);
	v1.push_back(28);
	v1.push_back(33);
	v1.push_back(40);
	v1.push_back(50);
	v1.push_back(30);
	v1.push_back(30);
	v1.push_back(30);

	vector<int>::iterator iter;
	iter = search_n(v1.begin(), v1.end(), 3, 30, Pred);

	cout << "iter : ";
	cout << *iter << endl;


	cout << "iter - 1 : ";
	cout << *(iter - 1) << endl;
	cout << "iter + 1 : ";
	cout << *(iter + 1) << endl;

	return 0;
}