#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class PrintFunctor
{
	char fmt;
public:
	explicit PrintFunctor(const char c = ' ') : fmt(c) {}
	void operator ()(int n) const
	{
		cout << n << fmt;
	}
};

int main()
{
	vector<int> v1;
	v1.push_back(10);
	v1.push_back(20);
	v1.push_back(30);
	v1.push_back(40);
	v1.push_back(50);

	for_each(v1.begin(), v1.end(), PrintFunctor());	//���ұ����� " " ��
	cout << endl;

	for_each(v1.begin(), v1.end(), PrintFunctor(','));
	cout << endl;

	for_each(v1.begin(), v1.end(), PrintFunctor('\n'));
	cout << endl;

	return 0;
}