#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class Accumulation
{
	int total;
public:
	explicit Accumulation(int init = 0) :total(init) {}
	void operator() (int& r)
	{
		total += r;
		r = total;
	}
};

int Func(int &r)
{
	return r + 5;
}

int main()
{
	vector<int> v;
	v.push_back(10);
	v.push_back(20);
	v.push_back(30);
	v.push_back(40);
	v.push_back(50);

	cout << "v : ";
	for (vector<int>::iterator iter = v.begin(); iter != v.end(); ++iter)
		cout << *iter << " ";
	cout << endl;

	for_each(v.begin(), v.end(), Accumulation(0));
	//for_each(v.begin(), v.end(), Func);

	cout << "v : ";
	for (vector<int>::iterator iter = v.begin(); iter != v.end(); ++iter)
		cout << *iter << " ";
	cout << endl;

	return 0;
}