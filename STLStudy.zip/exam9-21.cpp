#include <iostream>
#include <functional>
#include <vector>
#include <algorithm>
using namespace std;

template<typename RType, typename CType>
class Mem_fun_ref_class : public unary_function<CType, RType>
{
	RType (CType::* pf)() const;
public:
	Mem_fun_ref_class(RType(CType::*_pf)() const) :pf(_pf) {}
	RType operator()(const CType* p) const
	{
		return(p->*pf)();
	}
};

template<typename RType, typename CType>
Mem_fun_ref_class<RType, CType> Mem_fun_ref(RType(CType::* pf)() const)
{
	return Mem_fun_ref_class<RType, CType>(pf);
}

class Point
{
	int x;
	int y;
public:
	explicit Point(int _x = 0, int _y = 0) :x(_x), y(_y) {}
	void Print() const { cout << x << "," << y << endl; }
	int GetX() const { return x; }
	int GetY() const { return y; }
};

int main()
{
	vector<Point*> v;
	v.push_back(new Point(1, 1));
	v.push_back(new Point(2, 2));
	v.push_back(new Point(3, 3));
	v.push_back(new Point(4, 4));
	v.push_back(new Point(5, 5));

	//ȣ�� �Ұ���
	//for_each(v.begin(), v.end(), &Point::Print);
	//ȣ�� ����
	for_each(v.begin(), v.end(), Mem_fun_ref(&Point::Print));

	return 0;
}