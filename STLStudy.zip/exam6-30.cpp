#include <iostream>
#include <deque>
using namespace std;

int main()
{
	deque<int> dq;

	dq.push_back(10);
	dq.push_back(20);
	dq.push_back(30);
	dq.push_back(40);
	dq.push_back(50);

	deque<int>::iterator iter;
	for (iter = dq.begin(); iter != dq.end(); ++iter)
		cout << *iter << " ";
	cout << endl;

	iter = dq.begin() + 2;//�ݺ��ڿ� +2 �մϴ�.
	cout << *iter << " ";
	
	iter += 2;
	cout << *iter << " ";

	iter -= 3;
	cout << *iter << " ";

	return 0;
}