#include <iostream>
#include <list>
using namespace std;

int main()
{
	list<int> lt;
	list<int> lt2;

	lt.push_back(10);
	lt.push_back(20);
	lt.push_back(30);
	lt.push_back(40);
	lt.push_back(50);
	lt.push_back(10);

	lt2.push_back(15);
	lt2.push_back(5);
	lt2.push_back(65);

	list<int>::iterator iter;
	cout << "lt: ";
	for (iter = lt.begin(); iter != lt.end(); ++iter)
		cout << *iter << " ";
	cout << endl;

	cout << "lt2: ";
	for (iter= lt2.begin(); iter != lt2.end(); ++iter)
		cout << *iter << " ";
	cout << endl << "=================" << endl;

	lt.sort(greater<int>());
	lt2.sort(greater<int>());//����

	cout << "lt: ";
	for (iter = lt.begin(); iter != lt.end(); ++iter)
		cout << *iter << " ";
	cout << endl;

	cout << "lt2: ";
	for (iter = lt2.begin(); iter != lt2.end(); ++iter)
		cout << *iter << " ";
	cout << endl << "=================" << endl;

	lt.merge(lt2, greater<int>());	//lt2�� lt�� �պ�����. ���ı����� less

	cout << "lt: ";
	for (iter = lt.begin(); iter != lt.end(); ++iter)
		cout << *iter << " ";
	cout << endl;

	cout << "lt2: ";
	for (iter = lt2.begin(); iter != lt2.end(); ++iter)
		cout << *iter << " ";
	cout << endl << "=================" << endl;


	return 0;
}