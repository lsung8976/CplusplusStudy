#include <iostream>
using namespace std;

int main()
{
	int n1 = 10, n2 = 20;
	
	cout << n1 + n2 << endl;
	
	return 0;
}