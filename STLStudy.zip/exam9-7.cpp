#include <iostream>
#include <functional>
using namespace std;

template<typename T>
struct Plus : public binary_function<T, T, T>
{
	T operator()(const T& left, const T& right)
	{
		return left + right;
	}
};

int main()
{
	plus<int> oPlus;
	cout << oPlus(10, 20) << endl;

	cout << oPlus.operator()(10, 20) << endl;

	cout << plus<int>()(10, 20) << endl;
	cout << plus<int>().operator()(10, 20) << endl;

	return 0;
}