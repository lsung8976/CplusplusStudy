#include <iostream>
#include <functional>
#include <vector>
#include <algorithm>
using namespace std;

template<typename T>
struct Less
{
	bool operator()(T left, T right)
	{
		return left < right;
	}
};

bool Pred(int n)
{
	return 5 <= n && n <= 20;
}

class Point
{
	int x;
	int y;
public:
	explicit Point(int _x = 0, int _y = 0) :x(_x), y(_y)
	{}
	void Print() const { cout << x << "," << y << endl; }
	int GetX() const { return x; }
	int GetY() const { return y; }
};

template <typename RType, typename AType>
class Plus_Point
{
	RType (*pf)(AType);
public:
	Plus_Point(RType(*_pf)(AType)) : pf(_pf) {}
	{}
	RType operator()(AType n) const
	{
		return pf(n);
	}
};

template<typename RType, typename AType>
Plus_Point<RType, AType> Ptr_fun(RType(*pf)(Atype))
{
	return Plus_Point<RType, AType>(pf);
}

Point& Po_plus(const Point& p)
{
	
}

int main()
{
	vector<int> v;
	v.push_back(10);
	v.push_back(20);
	v.push_back(30);
	v.push_back(40);

	vector<Point> p_v;
	p_v.push_back(Point(10, 20));
	p_v.push_back(Point(20, 30));
	p_v.push_back(Point(30, 40));
	p_v.push_back(Point(40, 50));

	/*
	cout << Less<int>()(10, 20) << endl;
	for (vector<int>::size_type i = 0; i < v.size(); ++i)
		cout << v[i] << " ";
	cout << endl;

	

	binder1st<less<int>> binder = bind1st(less<int>(), 10);
	cout << binder(5) << endl;
	cout << count_if(v.begin(), v.end(), Pred) << endl;
	*/
	for_each(p_v.begin(), p_v.end(), )

	return 0;

}