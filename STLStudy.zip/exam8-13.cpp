#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

void Print(int n)
{
	cout << n << " ";
}

int main()
{
	vector<int> v1;
	v1.push_back(10);
	v1.push_back(20);
	v1.push_back(30);
	v1.push_back(40);
	v1.push_back(50);

	for_each(v1.begin(), v1.begin() + 2, Print);
	cout << endl;

	for_each(v1.begin(), v1.begin() + 4, Print);
	cout << endl;

	//[v.begin(), v.end()) ������ ���� ���
	for_each(v1.begin(), v1.end(), Print);
	cout << endl;
	return 0;
}