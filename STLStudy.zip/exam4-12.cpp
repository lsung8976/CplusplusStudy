#include <iostream>
#include <cstring>
using namespace std;

template<typename T>
class Array
{
private:
	T* buf;
	int size;
	int capacity;
public:
	explicit Array(int cap = 100) : buf(0), size(0), capacity(cap)
	{
		buf = new T[capacity];
	}

	~Array()
	{
		delete[] buf;
	}

	void Add(T data)
	{
		buf[size++] = data;
	}

	T operator[](int idx)
	{
		return buf[idx];
	}

	T operator[](int idx)	const
	{
		return buf[idx];
	}

	int GetSize() const
	{
		return size;
	}
};

int main()
{
	Array<int> arr1;
	arr1.Add(10);
	arr1.Add(20);
	arr1.Add(30);

	for (int i = 0; i < arr1.GetSize(); i++)
		cout << arr1[i] << endl;

	Array<double> arr2;
	arr2.Add(54316.412);
	arr2.Add(12.424);
	arr2.Add(231.2);

	for (int i = 0; i < arr2.GetSize(); i++)
		cout << arr2[i] << endl;

	Array<string> arr3;
	arr3.Add("Hello");
	arr3.Add("Everybody");
	arr3.Add("Thank you");

	for (int i = 0; i < arr3.GetSize(); i++)
		cout << arr3[i] << endl;

	return 0;
}