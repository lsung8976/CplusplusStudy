#include <iostream>
using namespace std;

/*
void For_each(int* begin, int* end, void (*pf)(int))
{
	while (begin != end)
	{
		pf(*begin++);
	}
}*/

template<typename IterT, typename Func>
void For_each(IterT* begin, IterT* end, Func pf)
{
	while (begin != end)
	{
		pf(*begin++);
	}
}

/*
void PrintInt(int data)
{
	cout << data << ' ';
}

void PrintString(string data)
{
	cout << data << ' ';
}
*/

template<typename T>
void Print(T data)
{
	cout << data << ' ';
}

int main()
{
	int arr[5] = { 10, 20, 30, 40, 50 };
	For_each(arr, arr + 5, Print<int>); //For_each<int*, void(*)(int)>(arr, arr+5, PrintInt) �Լ��ν��Ͻ�
	cout << endl;

	string sarr[3] = { "abc", "ABCDE", "HELLO"};
	For_each(sarr, sarr + 3, Print<string>); //For_each<string*, void(*)(string)>(sarr, sarr+3, PrintString) �Լ��ν��Ͻ�
	cout << endl;
	return 0;
}