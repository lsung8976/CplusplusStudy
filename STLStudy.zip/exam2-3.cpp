#include <iostream>
using namespace std;

void Print()
{
	cout << "���� �Լ� Print()" << endl;
}

class Point
{
public:
	void Print()
	{
		cout << "��� �Լ� Print()" << endl;
	}
};

int main()
{
	Point pt;
	Point* p = &pt;

	Print();
	pt.Print();
	p->Print();

	return 0;
}