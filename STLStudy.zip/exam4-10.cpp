#include <iostream>
#include <cstring>
using namespace std;

class IntArray
{
private:
	int* buf;
	int size;
	int capacity;
public:
	explicit IntArray(int cap = 100) : buf(0), size(0), capacity(cap)
	{
		buf = new int[capacity];
	}

	~IntArray()
	{
		delete[] buf;
	}
	
	void Add(int data)
	{
		buf[size++] = data;
	}

	int operator[](int idx)
	{
		return buf[idx];
	}

	int operator[](int idx)	const
	{
		return buf[idx];
	}
	
	int GetSize() const
	{
		return size;
	}
};

class DoubleArray
{
private:
	double* buf;
	int size;
	int capacity;
public:
	explicit DoubleArray(int cap = 100) : buf(0), size(0), capacity(cap)
	{
		buf = new double[capacity];
	}

	~DoubleArray()
	{
		delete[] buf;
	}

	void Add(double data)
	{
		buf[size++] = data;
	}

	double operator[](int idx)
	{
		return buf[idx];
	}

	double operator[](int idx)	const
	{
		return buf[idx];
	}

	int GetSize() const
	{
		return size;
	}
};

class StringArray
{
private:
	string* buf;
	int size;
	int capacity;
public:
	explicit StringArray(int cap = 100) : buf(0), size(0), capacity(cap)
	{
		buf = new string[capacity];
	}

	~StringArray()
	{
		delete[] buf;
	}

	void Add(string data)
	{
		buf[size++] = data;
	}

	string operator[](int idx)
	{
		return buf[idx];
	}

	string operator[](int idx)	const
	{
		return buf[idx];
	}

	int GetSize() const
	{
		return size;
	}
};

int main()
{
	IntArray arr1;
	arr1.Add(10);
	arr1.Add(20);
	arr1.Add(30);

	for (int i = 0; i < arr1.GetSize(); i++)
		cout << arr1[i] << endl;

	DoubleArray arr2;
	arr2.Add(54316.412);
	arr2.Add(12.424);
	arr2.Add(231.2);

	for (int i = 0; i < arr2.GetSize(); i++)
		cout << arr2[i] << endl;

	StringArray arr3;
	arr3.Add("Hello");
	arr3.Add("Everybody");
	arr3.Add("Thank you");

	for (int i = 0; i < arr3.GetSize(); i++)
		cout << arr3[i] << endl;

	return 0;
}