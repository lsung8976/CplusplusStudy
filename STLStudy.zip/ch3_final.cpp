#include <iostream>
using namespace std;

class Equal
{
public:
	bool operator()(int a, int b)
	{
		if (a == b)
			return true;
		else
			return false;
	}
};

struct Adder
{
	int operator()(int a, int b)
	{
		return a + b;
	}

}add;

int main()
{
	int sum = add(10, 20);
	Equal cmp;

	if (cmp(10,20))
		cout << "���� !" << endl;
	else
		cout << "�ٸ��� !" << endl;

	cout << "sum = " << sum << endl;
	return 0;
}