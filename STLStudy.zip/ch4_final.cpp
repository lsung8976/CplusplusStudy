
//���� 1

/*
#include <iostream>
using namespace std;

template<typename T>
void Copy(T dst, T src, int n)
{
	for (int i = 0; i < n; i++)
	{
		dst[i] = src[i];
	}
}

typedef double MyType;

int main()
{
	int arr1[5] = { 10,20,30,40,50 };
	int arr2[5];
	//Copy(t,s,n)	t:������ �ּ�, s:�ҽ��ּ�, n:���Ұ���
	Copy(arr2, arr1, 5);
	for (int i = 0; i < 5; i++)
	{
		cout << arr2[i] << endl;
	}

	MyType myArr1[5] = { 11.53,123123.43,2145.2435,35.213,6234.23 };
	MyType myArr2[5];
	Copy(myArr2, myArr1, 5);
	for (int i = 0; i < 5; i++)
	{
		cout << myArr2[i] << endl;
	}
	return 0;
}
*/

//���� 2

#include <iostream>
using namespace std;

template<typename T = int, int capT = 10>
class Stack
{
private:
	T* buf;
	int size;
	int capacity;
public:
	explicit Stack(int c = capT)
		:size(0), capacity(c)
	{
		buf = new T[c];
		for (int i = 0; i < capT; i++)
		{
			buf[i] = 0;
		}
	}

	void Push(T data)
	{
		if (size < 10)
			buf[size++] = data;
		else
			cout << "Full Memory" << endl;
	}

	T Pop()
	{
		T temp = buf[--size];
		buf[size] = 0;
		return temp;
	}

	bool Empty()
	{
		if (size == 0)
			return true;
		else
			return false;
	}

	~Stack()
	{
		delete[] buf;
	}

	void ShowStack()
	{
		for (int i = 0; i < capacity; i++)
		{
			cout << buf[i] << endl;
		}
	}
};

template <typename T = int, int capT = 10>
class Queue
{
private:
	T* buf;
	int size;
	int capacity;
	int cursor;
public:
	explicit Queue(int c = capT)
		:size(0), capacity(c), cursor(0)
	{
		buf = new T[c];
		for (int i = 0; i < capT; i++)
		{
			buf[i] = 0;
		}
	}

	void Push(T data)
	{
		if (size < 10)
			buf[size++] = data;
		else
			cout << "Full Memory" << endl;
	}

	T Pop()
	{
		T temp = buf[cursor];
		buf[cursor++] = 0;
		return temp;
	}

	bool Empty()
	{
		if (size == 0)
			return true;
		else
			return false;
	}

	~Queue()
	{
		delete[] buf;
	}

	void ShowStack()
	{
		for (int i = 0; i < capacity; i++)
		{
			cout << buf[i] << endl;
		}
	}
};

int main()
{
	Stack<int> st;

	st.Push(10);
	st.Push(20);
	st.Push(30);

	//st.ShowStack();
	
	if (!st.Empty())
		cout << st.Pop() << endl;	//30;

	if (!st.Empty())
		cout << st.Pop() << endl;	//20;

	if (!st.Empty())
		cout << st.Pop() << endl;	//10;
	
	//st.ShowStack();
	return 0;
}