#include <iostream>
#include <list>
using namespace std;


bool Predicate(int n)
{
	return 10 <= n && n <= 30;
}

int main()
{
	list<int> lt, lt2;

	lt.push_back(10);
	lt.push_back(20);
	lt.push_back(30);
	lt.push_back(40);
	lt.push_back(50);
	
	lt2.push_back(10);
	lt2.push_back(20);
	lt2.push_back(30);
	lt2.push_back(40);
	lt2.push_back(50);

	//lt.remove_if(Predicate); // �Ű����� (�Լ���������)
	list<int>::iterator iter = lt.begin();

	cout << "lt : ";
	for (; iter != lt.end(); ++iter)
		cout << *iter << " ";
	cout << endl;

	cout << "lt2 : ";
	for (iter = lt2.begin(); iter != lt2.end(); ++iter)
		cout << *iter << " ";
	cout << endl << "============" << endl;

	iter = lt.begin();
	++iter;
	++iter;	//30���ҿ� ��ġ��Ŵ

	lt.splice(iter, lt2);	//iter�� ����Ű�� ��ġ�� lt2�� �����Ҹ� �߶����

	cout << "lt : ";
	for (iter = lt.begin(); iter != lt.end(); ++iter)
		cout << *iter << " ";
	cout << endl;

	cout << "lt2 : ";
	for (iter = lt2.begin(); iter != lt2.end(); ++iter)
		cout << *iter << " ";
	cout << endl;


	return 0;
}