#include <iostream>
using namespace std;

class Point
{
private:
	int xpos, ypos;
public:
	Point(int x = 0, int y = 0)
		:xpos(x), ypos(y)
	{}
	void ShowPosition() const
	{
		cout << "[" << xpos << ", " << ypos << "]" << endl;
	}
	Point operator+(const Point& arg)
	{
		cout << "operator+() �Լ� ȣ��" << endl;
		Point pt;
		pt.xpos = this->xpos + arg.xpos;
		pt.ypos = this->ypos + arg.ypos;
		return pt;
	}
	Point &operator=(const Point& arg)
	{
		cout << "operator=() �Լ� ȣ��" << endl;
		this->xpos = arg.xpos;
		this->ypos = arg.ypos;
		return *this;
	}
};

int main()
{
	Point p1(2, 3), p2(5, 5);
	Point p3 = p1 + p2;
	Point p4 = p3;
	p3.ShowPosition();
	p4.ShowPosition();
	return 0;
}