#define _CRT_SCURE_NO_WARNNINGS
#include <iostream>
#include <string>
#include <stdlib.h>
using namespace std;

char* MakeStrAdr(int len)
{
	char* str = (char*)malloc(sizeof(char) * len);
	return str;
}

int main(void)
{
	char* str = MakeStrAdr(20);
	strcpy_s(str, 15, "I am so happy~");
	cout << str << endl;
	free(str);
	return 0;
}