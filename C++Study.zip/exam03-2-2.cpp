#include <iostream>
#include <cstring>
using namespace std;

enum
{
	LEN = 20
};

class Printer
{
private :
	char save_string[LEN];
public:
	void SetString(const char* str);
	void ShowString();
};

void Printer::SetString(const char* str)
{
	strcpy_s(save_string, str);
	return;
}

void Printer::ShowString()
{
	cout << save_string << endl;
}



int main(void)
{
	Printer pnt;
	pnt.SetString("Hello World!");
	pnt.ShowString();

	pnt.SetString("I love C++");
	pnt.ShowString();
	return 0;
}