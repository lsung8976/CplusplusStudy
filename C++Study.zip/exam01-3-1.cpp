#include <iostream>

int BoxVolume(int length, int width, int height)
{
	std::cout << "BoxVolume(int length, int width, int height) called : ";
	return length * width * height;
}

int BoxVolume(int length, int width)
{
	std::cout << "BoxVolume(int length, int width) called : ";
	return length * width * 1;
}

int BoxVolume(int length)
{
	std::cout << "BoxVolume(int length) called : ";
	return length * 1 * 1;
}

int main(void)
{
	std::cout << BoxVolume(3, 3, 3) << std::endl;
	std::cout << BoxVolume(5, 5) << std::endl;
	std::cout << BoxVolume(7) << std::endl;
	//	std::cout << "[D, D, D] :   " << BoxVolume() << std::endl;
	return 0;
}
