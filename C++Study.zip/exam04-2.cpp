#include <iostream>
using namespace std;

class Point
{
private:
	int xpos, ypos;
public:
	void Init(int x, int y)
	{
		xpos = x;
		ypos = y;
	}
	void ShowPointInfo() const
	{
		cout << "[" << xpos << ", " << ypos << "]" << endl;
	}
};

class Circle
{
private:
	Point dot;
	int rad;
public:
	void init(const Point pos, int num)
	{
		rad = num;
		dot = pos;
	}
	void ShowRadInfo() const
	{
		cout << "radius : " << rad << endl;
		dot.ShowPointInfo();
	}
};

class Ring
{
private:
	Circle in_cir;
	Circle out_cir;
public:
	void Init(int in_x, int in_y, int in_rad, int out_x, int out_y, int out_rad)
	{
		Point in_dot;
		Point out_dot;
		in_dot.Init(in_x, in_y);
		out_dot.Init(out_x, out_y);
		in_cir.init(in_dot, in_rad);
		out_cir.init(out_dot, out_rad);
	}
	void ShowRingInfo() const
	{
		cout << "Inner Circle Info..." << endl;
		in_cir.ShowRadInfo();
		cout << "outter Circle Info..." << endl;
		out_cir.ShowRadInfo();
	}
};

int main(void)
{
	Ring ring;
	ring.Init(1, 1, 4, 2, 2, 9);
	ring.ShowRingInfo();
	return 0;
}