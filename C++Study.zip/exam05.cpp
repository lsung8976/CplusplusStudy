#include <iostream>
#include <cstring>
using namespace std;

/*enum {
	NAME_LEN = 10,
	CN_LEN = 20,
	PN_LEN = 20
};*/


namespace COMP_POS
{
	enum
	{
		CLERK,
		SENIOR,
		ASSIST,
		MANAGER
	};
}

class NameCard
{
private:
	char* Name;
	char* companyName;
	char* phoneNum;
	int level;
public:
	NameCard(const char* name, const char* Cname, const char* Pnum, int lv)
		:level(lv)
	{
		Name = new char[strlen(name) + 1];
		companyName = new char[strlen(Cname) + 1];
		phoneNum = new char[strlen(Pnum) + 1];
		strcpy_s(Name, strlen(name) + 1, name);
		strcpy_s(companyName, strlen(Cname) + 1, Cname);
		strcpy_s(phoneNum, strlen(Pnum) + 1, Pnum);
	}

	NameCard(const NameCard& copy) // ���������
		:level(copy.level)
	{
		Name = new char[strlen(copy.Name) + 1];
		companyName = new char[strlen(copy.companyName) + 1];
		phoneNum = new char[strlen(copy.phoneNum) + 1];
		strcpy_s(Name, strlen(copy.Name) + 1, copy.Name);
		strcpy_s(companyName, strlen(copy.companyName) + 1, copy.companyName);
		strcpy_s(phoneNum, strlen(copy.phoneNum) + 1, copy.phoneNum);
	}

	void ShowNameCardInfo() const
	{

		cout << "�̸�: " << Name << endl;
		cout << "ȸ���: " << companyName << endl;
		cout << "��ȭ��ȣ: " << phoneNum << endl;
		cout << "����: ";
		switch (level)
		{
		case COMP_POS::CLERK: cout << "���" << endl;;
			break;
		case COMP_POS::SENIOR: cout << "����" << endl;;
			break;
		case COMP_POS::ASSIST: cout << "�븮" << endl;;
			break;
		case COMP_POS::MANAGER: cout << "����" << endl;;
			break;
		}

	}
	~NameCard()
	{
		delete[] Name;
		delete[] companyName;
		delete[] phoneNum;
	}
};

int main(void)
{
	NameCard manClerk("Lee", " ABCEng", "010-1111-2222", COMP_POS::CLERK);
	NameCard copy1 = manClerk;
	NameCard manSENIOR("HONG", "OrangeEng", "010-3333-4444", COMP_POS::SENIOR);
	NameCard copy2 = manSENIOR;
	copy1.ShowNameCardInfo();
	copy2.ShowNameCardInfo();
	return 0;
}