#include <iostream>
#include "sclass.h"

using namespace std;

void FruitSeller::InitMembers(int price, int num, int money)
{
	APPLE_PRICE = price;
	numOfApples = num;
	myMoney = money;
}
int FruitSeller::SaleApples(int money)
{
	if (money < 0)
	{
		cout << "���� ������ �ټ� �����ϴ�." << endl;
		return 0;
	}
	int num = money / APPLE_PRICE;
	numOfApples -= num;
	myMoney += money;
	return num;
}
void FruitSeller::ShowSalesResult() const
{
	cout << "���� ��� : " << GetnumOfApples() << endl;
	cout << "�Ǹ� ���� : " << GetmyMoney() << endl << endl;
}
int FruitSeller::GetAPPLE_PRICE() const
{
	return APPLE_PRICE;
}
int FruitSeller::GetmyMoney() const
{
	return myMoney;
}
int FruitSeller::GetnumOfApples() const
{
	return numOfApples;
}