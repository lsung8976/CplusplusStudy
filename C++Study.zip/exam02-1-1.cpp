#include <iostream>
using namespace std;

int Add_ref(int& ref1, int& ref2)
{
	ref1 += 1;
	ref2 += 1;
	return 0;
}

int Conv_ref(int& ref)
{
	ref *= -1;
	return 0;
}

int main(void)
{
	int num1 = 10;
	int num2 = 20;
	int val = 100;

	Add_ref(num1, num2);
	
	cout << "Called Add_func()" << endl;
	cout << "num1 : " << num1 << " num2 : " << num2 << endl;

	Conv_ref(val);

	cout << "Called Change_func()" << endl;
	cout << "val : " << val << endl;

	return 0;
}