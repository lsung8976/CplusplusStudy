#ifndef __POINT_H__
#define __POINT_H__

#include <iostream>

class Point
{
private:
	int xpos, ypos;
public:
	Point(int x = 0, int y = 0);
	friend ostream& operator<<(ostream& os, const Point& pos);
}

//BoundCheckArray 13-2è��


/*

class Point
{
private : 
	int x;
	int y;

public:
	Point(const int &xpos, const int &ypos);
	//bool InitMember(int xpos, int ypos);
	int GetX() const;
	int GetY() const;
	bool SetX(int xpos);
	bool SetY(int ypos);
};*/
#endif
//