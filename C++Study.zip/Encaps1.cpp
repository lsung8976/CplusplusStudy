#include <iostream>
using namespace std;

class sinivelCap // �๰
{
public:
	void Take() const { cout << "�๰�� ��~ ���ϴ�" << endl; }
};

class sneezeCap // ��ä��
{
public:
	void Take() const { cout << "��ä�Ⱑ �ܽ��ϴ�." << endl; }
};

class snuffleCap // �ڸ���
{
public:
	void Take() const { cout << "�ڰ� �� �Ը��ϴ�." << endl; }
};

class ColdPatient {
public:
	void TakeSinivelCap(const sinivelCap& cap) const { cap.Take(); }
	void TakeSneezeCap(const sneezeCap& cap) const { cap.Take(); }
	void TakeSnuffleCap(const snuffleCap& cap) const { cap.Take(); }
};

int main(void)
{
	sinivelCap scap;
	sneezeCap zcap;
	snuffleCap ncap;

	ColdPatient sufferer;
	sufferer.TakeSinivelCap(scap);
	sufferer.TakeSneezeCap(zcap);
	sufferer.TakeSnuffleCap(ncap);
	return 0;
}