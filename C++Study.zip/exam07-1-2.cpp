#include <iostream>
#include <cstring>
using namespace std;

class MyFriendInfo
{
private:
	char* name;
	int age;
public:
	MyFriendInfo(const char* myname, int myage) : age(myage)
	{
		name = new char[strlen(myname) + 1];
		strcpy_s(name, strlen(myname) + 1, myname);
	}
	~MyFriendInfo()
	{
		delete[] name;
	}
	void ShowMyFriendInfo()
	{
		cout << "�̸� : " << name << endl;
		cout << "���� : " << age << endl;
	}
};

class MyFriendDetailInfo : public MyFriendInfo
{
private :
	char* addr;
	char* phone;
public:
	MyFriendDetailInfo(const char* fname, int fage, const char* faddr, const char* fphone) : MyFriendInfo(fname, fage) 
	{
		addr = new char[strlen(faddr) + 1];
		strcpy_s(addr, strlen(faddr) + 1, faddr);

		phone = new char[strlen(fphone) + 1];
		strcpy_s(phone, strlen(fphone) + 1, fphone);
	}
	~MyFriendDetailInfo()
	{
		delete[] addr;
		delete[] phone;
	}
	void ShowMyFriendDetailInfo()
	{
		ShowMyFriendInfo();
		cout << "�ּ� : " << addr << endl;
		cout << "��ȭ : " << phone << endl << endl;
	}

};

int main()
{
	MyFriendDetailInfo bestfriend("peter", 20, "������", "010-1111-2222");
	bestfriend.ShowMyFriendDetailInfo();


















































































}