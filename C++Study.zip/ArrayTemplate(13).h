#ifndef __ARRAY_TEMPLATE_H__
#define __ARRAY_TEMPLATE_H__

#include <iostream>
#include <cstdlib>
using namespace std;

template <typename T>
class BoundCheckArray
{
private:
	T* arr;
	int arrLen;

	BoundCheckArray(const BoundCheckArray& arr) {}
	BoundCheckArray& operator=(const BoundCheckArray& arr) {}
public:
	BoundCheckArray(int n)
		:arrLen(n)
	{
		arr = new T[arrLen];
	}
	T& operator[] (int idx)
	{
		if (idx < 0 || idx >= arrLen)
		{
			cout << "Array index out of bound exception" << endl;
			exit(1);
		}
		return arr[idx];
	}
	T& operator[] (int idx) const
	{
		if (idx<0 || idx>arrLen)
		{
			cout << "Array index out of bound exception" << endl;
			exit(1);
		}
		return arr[idx];
	}
	int GetArrLen() const { return arrLen; }

	~BoundCheckArray()
	{
		delete[] arr;
	}
};
#endif