#include <iostream>
using namespace std;

class Point
{
private:
	int xpos, ypos;
public:
	Point(int x = 0, int y = 0) :xpos(x), ypos(y)
	{ }
	void ShowPosition() const
	{
		cout << "[" << xpos << ", " << ypos << "]" << endl;
	}
	friend ostream& operator<<(ostream& ostm, Point& ref);
};

ostream& operator<<(ostream& ostm, Point& ref)
{
	ostm << "[" << ref.xpos << ", " << ref.ypos << "]" << endl;
	return ostm;
}

int main(void)
{
	Point pos(1, 2);

	cout << pos;

	return 0;
}