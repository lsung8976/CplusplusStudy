#include <iostream>
#include <cstring>
using namespace std;

class Gun
{
private:
	int bullet;
public:
	Gun(int bnum) : bullet(bnum)
	{}
	void Shot()
	{
		if (bullet > 0)
		{
			cout << "BBANG!" << endl;
			bullet--;
		}
		else 
		{
			cout << "no bullet" << endl;
		}
	}
};

class Police
{
private:
	int handcuffs;
	Gun* pistol;
public:
	Police(int bnum = 0, int bcuff = 0)
		:handcuffs(bcuff)
	{
		if (bnum > 0)
		{
			pistol = new Gun(bnum);
		}
		else
		{
			pistol = NULL;
		}
	}
	Police(Police& copy)
	{
		handcuffs = copy.handcuffs;
		delete[] pistol;
		if (copy.pistol != NULL)
		{
			pistol = new Gun((*copy.pistol));
		}
		else
		{
			pistol = NULL;
		}
		cout << "I'm copyConstructor" << endl;
	}
	Police& operator=(Police& ref)
	{
		handcuffs = ref.handcuffs;
		delete pistol;
		if (ref.pistol != NULL)
		{
			pistol = new Gun((*ref.pistol));
		}
		else
		{
			pistol = NULL;
		}
		cout << "I'm =operator()" << endl;
		return *this;
	}
	void PutHandCuff()
	{
		cout << "SNAP!" << endl;
		handcuffs--;
	}
	void Shot()
	{
		if (pistol == NULL)
			cout << "Hut BBANG" << endl;
		else
			pistol->Shot();
	}
	~Police()
	{
		delete pistol;
	}
};

int main(void)
{
	Police pman1(1, 2);
	Police pman1cpy;
	pman1cpy = pman1;
	pman1cpy.Shot();
	pman1cpy.PutHandCuff();
	Police pman1cpy2(pman1cpy);
	pman1cpy2.Shot();

	/*Police pman2(0, 3); // no pistol man
	pman2.Shot();
	pman2.PutHandCuff();*/
	return 0;
}