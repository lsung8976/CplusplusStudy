#include <iostream>
#include <cstring>

using namespace std;

int main(void)
{
	char s[40] = "special";
	char c_s[40];
	cout << strlen(s) << endl;

	strcat_s(s, " force");
	cout << s << endl;

	strcpy_s(c_s, strlen(s) + 1, s);
	cout << c_s << endl;

	
	strcat_s(c_s, " hello World");
	cout << "���ڿ��� ���մϴ�(0 : ����) " << endl;
	cout << "s : " << s << endl;
	cout << "c_s : " << c_s << endl;
	cout << strcmp(s, c_s) << endl;
	return 0;
}