#include <iostream>

namespace Hybrid
{
	namespace special {
		void SpFunc(void)
		{
			std::cout << "So Simple function" << std::endl;
			std::cout << "In namespace Hybrid::special!" << std::endl;
		}
		int SpNum = 22;
	}
	int HybNum = 33;
}

int main()
{
	using namespace Hybrid; // using namespace ����Ѱ� (1)
	//SpFunc();
	std::cout << special::SpNum << std::endl; //�����. (2)

	std::cout << HybNum << std::endl; 
	return 0;
}