#include <iostream>
#include "ArrayTemplate.h"
#include "Point.h"
using namespace std;

int main(void)
{
	BoundCheckArray<int> iarr(5);

	for (int i = 0; i < 4; i++)
	{
		iarr[i] = (i + 1) * 11;
		cout << iarr[i] << endl;
	}

	BoundCheckArray<Point> arr2(3);
	arr2[0] = Point(1, 2);
	arr2[1] = Point(4, 5);
	arr2[2] = Point(82, 12);
	for (int i = 0; i < 3; i++)
		cout << arr2[i];

	typedef Point* POINT_PTR;
	BoundCheckArray<POINT_PTR> arr3(3);
	arr3[0] = new Point(1, 2);
	arr3[1] = new Point(24, 56);
	arr3[2] = new Point(78, 8);

	for (int i = 0; i < 4; i++)
		cout << *(arr3[i]);

	delete arr3[0];
	delete arr3[1];
	delete arr3[2];

	return 0;
}