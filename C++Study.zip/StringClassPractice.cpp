#include <iostream>
#include <cstring>
using namespace std;

class String
{
private:
	char* ptr;
public:
	String(const char* str)
	{
		int len = strlen(str) + 1;
		ptr = new char[len];
		strcpy_s(ptr, len, str);
	}
	String(const String& cpy)
	{
		delete[] ptr;
		ptr = new char[strlen(cpy.ptr) + 1];
		strcpy_s(ptr, strlen(cpy.ptr) + 1, cpy.ptr);
	}
	
	String& operator=(const String& cpy)
	{
		delete[] ptr;
		ptr = new char[strlen(cpy.ptr) + 1];
		strcpy_s(ptr, strlen(cpy.ptr) + 1, cpy.ptr);
		return *this;
	}
	String operator+(const String &src)
	{
		char* stringcpy;
		int destLen = strlen(ptr) + 1;
		int srcLen = strlen(src.ptr);
		stringcpy = new char[destLen];
		strcpy_s(stringcpy, destLen, ptr);
		strcat_s(stringcpy, destLen + srcLen, src.ptr);
		String addString(stringcpy);

		return addString;
	}

	String& operator+=(const String& src)
	{
		delete[] ptr;
		int len = sizeof(ptr) + 1;
		strcat_s(ptr, len + sizeof(src.ptr), src.ptr);
		return *this;
	}


	void ShowString() const
	{
		cout << ptr << endl;
	}
	~String()
	{
		delete[] ptr;
	}
};





int main(void)
{
	String str1("cheese");
	String str2(str1);
	String str3 = str2;
	String str4("Mice");
	String str5 = str1 + str4;
	str1.ShowString();
	str2.ShowString();
	str3.ShowString();
	str5.ShowString();
	//str2 += str4;
	str2.operator+=(str4);
	str2.ShowString();
	return 0;
}