#include <iostream>
using namespace std;

class sinivelCap // �๰
{
public:
	void Take() const { cout << "�๰�� ��~ ���ϴ�" << endl; }
};

class sneezeCap // ��ä��
{
public:
	void Take() const { cout << "��ä�Ⱑ �ܽ��ϴ�." << endl; }
};

class snuffleCap // �ڸ���
{
public:
	void Take() const { cout << "�ڰ� �� �Ը��ϴ�." << endl; }
};

class CONTAC600
{
private:
	sinivelCap sin;
	sneezeCap sne;
	snuffleCap snu;

public:
	void Take() const
	{
		sin.Take();
		sne.Take();
		snu.Take();
	}
};

class ColdPatient {
public:
	void TakeCONTAC600(const CONTAC600& cap) const { cap.Take(); }
};

int main(void)
{
	CONTAC600 cap;
	ColdPatient sufferer;
	sufferer.TakeCONTAC600(cap);
	return 0;
}