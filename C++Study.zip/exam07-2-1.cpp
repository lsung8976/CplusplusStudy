#include <iostream>
using namespace std;

class Rectangle
{
private:
	int width;
	int length;
public:
	Rectangle(int n1, int n2) : width(n1), length(n2) {}
	void ShowAreaInfo()
	{
		cout << "Area : " << width * length << endl;
	}

};

class Square : public Rectangle
{
public:
	Square(int n1) : Rectangle(n1, n1) {}
};

int main(void)
{
	Rectangle rec(4, 3);
	rec.ShowAreaInfo();

	Square sqr(7);
	sqr.ShowAreaInfo();
	return 0;
}