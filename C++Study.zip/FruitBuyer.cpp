#include "Bclass.h"
#include <iostream>
using namespace std;

void FruitBuyer::InitMember(int money)
{
	myMoney = money;
	numOfApples = 0;
}
void FruitBuyer::BuyApples(FruitSeller& seller, int money)
{
	if (money < 0)
	{
		cout << "���� ������ �ټ� �����ϴ�." << endl;
		return;
	}
	numOfApples += seller.SaleApples(money);
	myMoney -= money;
}
void FruitBuyer::ShowBuyResult() const
{
	cout << "��� ���� : " << GetnumOfApples() << endl;
	cout << "���� �ܾ� : " << GetmyMoney() << endl;
}
int FruitBuyer::GetmyMoney() const
{
	return myMoney;
}
int FruitBuyer::GetnumOfApples() const
{
	return numOfApples;
}
