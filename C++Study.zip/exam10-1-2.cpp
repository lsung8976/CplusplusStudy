#include <iostream>
using namespace std;

class Point
{
private:
	int xpos, ypos;
public:
	Point(int x, int y)
		:xpos(x), ypos(y) { }
	Point& operator+=(const Point& ref)
	{
	    xpos += ref.xpos;
		ypos += ref.ypos;
		return *this;
	}

	Point& operator-=(const Point& ref)
	{
		xpos -= ref.xpos;
		ypos -= ref.ypos;
		return *this;
	}
	void ShowPosition() const
	{
		cout << '[' << xpos << ", " << ypos << ']' << endl;
	}
};

int main(void)
{
	Point pos1(10, 20);
	Point pos2(21, 31);

	Point pos3(50, 50);
	Point pos4(25, 35);


	pos1 += pos2;

	pos3 -= pos4;

	pos1.ShowPosition();
	pos3.ShowPosition();

	return 0;
}