#include <iostream>
using namespace std;

class Point
{
private:
	int xpos, ypos;
public:
	Point(int x, int y)
		:xpos(x), ypos(y) { }
	friend bool operator==(const Point& ref1, const Point& ref2);
	friend bool operator!=(const Point& ref1, const Point& ref2);
};

bool operator==(const Point& ref1, const Point& ref2)
{
	if (ref1.xpos == ref2.xpos && ref1.ypos == ref2.ypos)
		return true;
	else
		return false;
}

bool operator!=(const Point& ref1, const Point& ref2)
{
	return !(ref1 == ref2);
}

int main(void)
{
	Point pos1(10, 20);
	Point pos2(21, 31);

	cout << (pos1 != pos2) << endl;

	return 0;
}