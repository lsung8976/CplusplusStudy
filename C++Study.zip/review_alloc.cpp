#include <stdio.h>
#include <stdlib.h>
#define _CRT_SECURE_NO_WARNINGS

/*
int main()
{
	int arr[4] = { 1,2,3,4 };
	int* pArr;

	pArr = (int*)malloc(sizeof(int) * 4);

	if (pArr == NULL)
	{
	
		printf("mallco error");
	}

	for (int i = 0; i < 4; i++)
	{
		pArr[i] = arr[i];
	}

	for (int i = 0; i < 4; ++i)
	{
		printf("%d \n", pArr[i]);
	}

	free(pArr);
	system("Pause");

	return 0;

}*/
/*
int main()
{
	int num;
	int* m_arr;

	printf("��� �迭�� �����Ͻðڽ��ϱ� ? : ");
	scanf_s("%d", &num);

	m_arr = (int*)malloc(sizeof(int) * num);

	for (int i = 0; i < num; i++)
	{
		scanf_s("%d", &m_arr[i]);
	}
	for (int i = 0; i < num; i++)
	{
		printf("%d ��° �� : %d \n", i, m_arr[i]);

	}

	free(m_arr);
	system("pause");

	return 0;
}*/
