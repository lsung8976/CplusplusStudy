#include <iostream>
using namespace std;

class Calculator
{
private:
	int Add_count = 0;
	int Min_count = 0;
	int Mul_count = 0;
	int Div_count = 0;
public:
	double Add(double num1, double num2);
	double Min(double num1, double num2);
	double Div(double num1, double num2);
	double Mul(double num1, double num2);
	void ShowOpCount();
};

double Calculator::Add(double num1, double num2)
{
	Add_count += 1;
	return num1 + num2;
}

double Calculator::Min(double num1, double num2)
{
	Min_count += 1;
	return num1 - num2;
}

double Calculator::Div(double num1, double num2)
{
	Div_count += 1;
	return num1 / num2;
}

double Calculator::Mul(double num1, double num2)
{
	Mul_count += 1;
	return num1 * num2;
}

inline void Calculator::ShowOpCount()
{
	cout << "���� : " << Add_count << " ���� : " << Min_count << " ���� : "<< Mul_count <<" ������ : " << Div_count << endl;
}

int main()
{
	Calculator cal;
	cout << "3.2 + 2.4 = " << cal.Add(3.2, 2.4) << endl;
	cout << "3.5 / 1.7 = " << cal.Div(3.5, 1.7) << endl;
	cout << "2.2 - 1.5 = " << cal.Min(2.2, 1.5) << endl;
	cout << "4.9 / 1.2 = " << cal.Div(4.9, 1.2) << endl;
	cal.ShowOpCount();
}