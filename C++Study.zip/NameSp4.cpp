#include <iostream>

namespace Parent 
{
	int num = 1;
	namespace SonOne
	{	
		int num = 2;
		namespace SonTwo
		{
			int num = 3;
		}
	}
}

int main(void)
{
	std::cout << Parent::num << std::endl;
	std::cout << Parent::SonOne::num << std::endl;
	std::cout << Parent::SonOne::SonTwo::num << std::endl;
}