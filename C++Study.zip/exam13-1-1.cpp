#include <iostream>
using namespace std;

class Point
{
private:
	int xpos, ypos;
public:
	Point(int x = 0, int y = 0)
		:xpos(x), ypos(y) {}
	void ShowPosition() const
	{
		cout << "[" << xpos << ", " << ypos << "]" << endl;
	}
};

template <typename T>
T SwapData(T &num1, T &num2)
{
	T temp;
	temp = num1;
	num1 = num2;
	num2 = temp;
	return 0;
}

int main(void)
{
	Point p1(10, 20);
	Point p2(21, 31);

	int a = 10;
	int b = 20;

	SwapData(p1, p2);
	p1.ShowPosition();
	p2.ShowPosition();

	SwapData(a, b);
	cout << a << ", " << b << endl;


	return 0;
}