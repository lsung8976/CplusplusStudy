#ifndef __BCLASS_H__
#define __BCLASS_H__
#include "sclass.h"

class FruitBuyer
{
	int myMoney;	// private
	int numOfApples; // private
public:
	void InitMember(int money);
	void BuyApples(FruitSeller& seller, int money);
	void ShowBuyResult() const;
	int GetmyMoney() const;
	int GetnumOfApples() const;
};

#endif