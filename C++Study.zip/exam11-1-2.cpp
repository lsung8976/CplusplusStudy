#include <iostream>
#include <cstring>
using namespace std;

class Book
{
private:
	char* title;
	char* isbn;
	int price;
public:
	Book(const char* name = NULL, const char* readisbn = NULL, int money = 0)
		: price(money)
	{
		if (name != NULL)
		{
			title = new char[strlen(name) + 1];
			strcpy_s(title, strlen(name) + 1, name);
			isbn = new char[strlen(readisbn) + 1];
			strcpy_s(isbn, strlen(readisbn) + 1, readisbn);
		}
		else
		{
			title = NULL;
			isbn = NULL;
		}
	}
	Book(const Book& cpy)
		: price(cpy.price)
	{
		delete title;
		title = new char[strlen(cpy.title) + 1];
		strcpy_s(title, strlen(cpy.title) + 1, cpy.title);
		delete isbn;
		isbn = new char[strlen(cpy.isbn) + 1];
		strcpy_s(isbn, strlen(cpy.isbn) + 1, cpy.isbn);
	}
	Book& operator=(const Book& ref)
	{
		price = ref.price;
		delete title;
		title = new char[strlen(ref.title) + 1];
		strcpy_s(title, strlen(ref.title) + 1, ref.title);
		delete isbn;
		isbn = new char[strlen(ref.isbn) + 1];
		strcpy_s(isbn, strlen(ref.isbn) + 1, ref.isbn);
		return *this;
	}
	void ShowBookInfo()
	{
		cout << "����: " << title << endl;
		cout << "ISBN: " << isbn << endl;
		cout << "����: " << price << endl;
	}
	~Book()
	{
		delete[] title;
		delete[] isbn;
	}
};

class EBook : public Book
{
private:
	char* DRMKey;
public:
	EBook(const char* name = NULL, const char* readisbn = NULL, int money = 0, const char* key = NULL)
		: Book(name, readisbn, money)
	{
		if (key != NULL)
		{
			DRMKey = new char[strlen(key) + 1];
			strcpy_s(DRMKey, strlen(key) + 1, key);
		}
		else
		{
			DRMKey = NULL;
		}
	}
	EBook(const EBook &cpy)
		:Book(cpy)
	{
		cout << "I am copyCOnstrucotr" << endl;
		delete DRMKey;
		DRMKey = new char[strlen(cpy.DRMKey) + 1];
		strcpy_s(DRMKey, strlen(cpy.DRMKey) + 1, cpy.DRMKey);
	}
	EBook& operator=(const EBook& ref)
	{
		cout << "i am operator=()" << endl;
		Book::operator=(ref);
		delete DRMKey;
		DRMKey = new char[strlen(ref.DRMKey) + 1];
		strcpy_s(DRMKey, strlen(ref.DRMKey) + 1, ref.DRMKey);
		return *this;
	}
	~EBook()
	{
		delete[] DRMKey;
	}
	void ShowEbookInfo()
	{
		ShowBookInfo();
		cout << "����Ű: " << DRMKey << endl;
		cout << "�ּҰ�: " << &DRMKey << endl;
	}
};

int main(void)
{
	Book book("���� C++", "555-12345-890-0", 20000);
	book.ShowBookInfo();
	cout << endl;
	EBook ebook("���� C++ Ebook", "555-12345-890-0", 10000, "fdx9w0i8kiw");
	ebook.ShowEbookInfo();

	EBook cpybook;
	cpybook = ebook;
	cpybook.ShowEbookInfo();

	return 0;
}