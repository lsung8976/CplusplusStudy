#include <iostream>
using namespace std;

class Point
{
private:
	int xpos, ypos;
public:
	Point(int x, int y)
		:xpos(x), ypos(y) { }
	friend Point operator-(const Point& ref1, const Point& ref2);
	void ShowPosition() const
	{
		cout << '[' << xpos << ", " << ypos << ']' << endl;
	}
};
Point operator-(const Point& ref1, const Point& ref2)
{
	Point pos(ref1.xpos - ref2.xpos, ref1.ypos - ref2.ypos);
	return pos;
}

int main(void)
{
	Point pos1(10, 20);
	Point pos2(21, 31);
	Point pos3 = pos2 - pos1;

	pos1.ShowPosition();
	pos2.ShowPosition();
	pos3.ShowPosition();
	return 0;
}