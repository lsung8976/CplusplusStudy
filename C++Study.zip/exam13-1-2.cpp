#include <iostream>
using namespace std;

template <class A>
A SumArray(A arr[], int len)
{
	A sum = 0;
	for (int i = 0; i < len ; i++)
	{
		sum += arr[i];
	}
	return sum;
}

int main(void)
{
	double arr1[4] = { 25.4,69.2, 67.7, 67.2 };
	int arr2[4] = { 41, 75, 152, 32};

	cout << SumArray(arr1, 4) << endl;
	cout << SumArray(arr2, 4) << endl;

}