#include <iostream>
#include <cstring>
using namespace std;

class Book
{
private:
	char* title;
	char* isbn;
	int price;
public:
	Book(const char* name, const char* readisbn, int money)
		: price(money)
	{
		title = new char[strlen(name) + 1];
		strcpy_s(title, strlen(name) + 1, name);
		isbn = new char[strlen(readisbn) + 1];
		strcpy_s(isbn, strlen(readisbn) + 1, readisbn);
	}
	void ShowBookInfo()
	{
		cout << "����: " << title << endl;
		cout << "ISBN: " << isbn << endl;
		cout << "����: " << price << endl;
	}
	~Book()
	{
		delete[] title;
		delete[] isbn;
	}
};

class EBook : public Book
{
private:
	char* DRMKey;
public:
	EBook(const char* name, const char* readisbn, int money, const char* key)
		: Book(name, readisbn, money)
	{
		DRMKey = new char[strlen(key) + 1];
		strcpy_s(DRMKey, strlen(key) + 1, key);
	}
	~EBook()
	{
		delete[] DRMKey;
	}
	void ShowEbookInfo()
	{
		ShowBookInfo();
		cout << "����Ű: " << DRMKey << endl;
	}
};

int main(void)
{
	Book book("���� C++", "555-12345-890-0", 20000);
	book.ShowBookInfo();
	cout << endl;
	EBook ebook("���� C++ Ebook", "555-12345-890-0", 10000, "fdx9w0i8kiw");
	ebook.ShowEbookInfo();
	return 0;
}