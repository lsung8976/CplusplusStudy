#include <iostream>
using namespace std;

template <typename T>
class Point
{
private:
	T xpos, ypos;
public:
	Point(T x = 0, T y = 0);
	void ShowPosition() const;

	friend Point<int> operator+(const Point<int>& ref1, const Point<int>& ref2);
	friend ostream& operator<<(ostream& os, Point<int>& pos);
};

template <typename T>
Point<T>::Point(T x, T y) : xpos(x), ypos(y)
{}

template <typename T>
void Point<T>::ShowPosition() const
{
	cout << "[" << xpos << ", " << ypos << "]" << endl;
}

Point<int> operator+(const Point<int>& ref1, const Point<int>& ref2)
{
	return Point<int>(ref1.xpos + ref2.xpos, ref1.ypos + ref2.ypos);
}

ostream& operator<<(ostream& os, Point<int>& pos)
{
	os << "[" << pos.xpos << ", " << pos.ypos << "]" << endl;
	return os;
}

int main(void)
{
	Point<int> pos1(3, 4);
	Point<int> pos2(5, 6);
	Point<int> pos3 = pos1 + pos2;

	cout << pos1 << pos2 << pos3;
	return 0;
}