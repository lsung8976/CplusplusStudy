#include <iostream>
#include <math.h>
using namespace std;

typedef struct __Point
{
	int xpos;
	int ypos;
} Point;

Point& PntAdder(const Point& p1, const Point& p2)
{
	Point* add_str = new Point;
	add_str->xpos = p1.xpos + p2.xpos;
	add_str->ypos = p1.ypos + p2.ypos;

	return *add_str;

}
        
int main(void)
{	
	Point* ptr1 = new Point;

	ptr1->xpos = 11;
	ptr1->ypos = 22;

	Point* ptr2 = new Point;
	ptr2->xpos = 10;
	ptr2->ypos = 20;

	const Point &sum = PntAdder(*ptr1, *ptr2);
	
	cout << sum.xpos << " " << sum.ypos << endl;

	delete ptr1;
	delete ptr2;
	delete &sum;
}
