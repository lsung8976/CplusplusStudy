#include <iostream>
using namespace std;


class Point
{
private:
	int xpos, ypos;
public:
	Point(int x = 0, int y = 0) :xpos(x), ypos(y)
	{ }
	void ShowPosition() const
	{
		cout << "[" << xpos << ", " << ypos << "]" << endl;
	}
	friend ostream& operator<<(ostream& ostm, Point& ref);
	friend istream& operator>>(istream& istm, Point& ref);
};

istream& operator>>(istream& istm, Point& ref)
{
	int x, y;
	cin >> x >> y;
	ref.xpos = x;
	ref.ypos = y;
	return istm;
}


ostream& operator<<(ostream& ostm, Point& ref)
{
	ostm << "[" << ref.xpos << ", " << ref.ypos << "]" << endl;
	return ostm;
}

int main(void)
{
	//Point pos(1, 2);
	Point new_pos;
	//cout << pos;

	cout << "x, y ��ǥ������ �Է�" << endl;
	cin >> new_pos;
	cout << new_pos;


	return 0;
}