#include <iostream>
using namespace std;

class Point
{
private:
	int xpos;
	int ypos;
public:
	Point(int x, int y) : xpos(x), ypos(y)
	{}
	
	Point operator-()
	{
		Point new_pos(xpos, ypos);
		new_pos.xpos *= -1;
		new_pos.ypos *= -1;
		return new_pos;
	}

	void ShowPosition() const
	{
		cout << "[" << xpos << ", " << ypos << "]" << endl;
	}
	//friend Point operator-(Point pos);
	friend Point operator~(Point pos);
};

/*Point operator-(Point pos)
{
	pos.xpos *= -1;
	pos.ypos *= -1;
	return pos;
}*/

Point operator~(Point pos)
{
	Point new_pos(~pos.xpos, ~pos.ypos);

	return new_pos;
}

int main(void)
{
	Point pos1(1, 2);

	Point pos2 = ~pos1;

	pos1.ShowPosition();
	pos2.ShowPosition();

}