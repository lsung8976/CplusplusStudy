#ifndef __FCLASS_H__
#define __FCLASS_H__

class FruitSeller
{
private:
	int APPLE_PRICE;
	int numOfApples;
	int myMoney;
public:
	void InitMembers(int price, int num, int money);
	int SaleApples(int money);
	void ShowSalesResult() const;
	int GetAPPLE_PRICE() const;
	int GetmyMoney() const;
	int GetnumOfApples() const;
};

#endif