#include <iostream>
using namespace std;

class Point
{
private:
	int xpos, ypos;
public:
	Point(int x = 0, int y = 0)
		:xpos(x), ypos(y)
	{}
	
	void ShowPosition() const
	{
		cout << "[" << xpos << ", " << ypos << "]" << endl;
	}
	void SetPos(int x, int y)
	{
		xpos = x;
		ypos = y;
	}

};

template <typename T>
class SmartPtr
{
private:
	T* posptr;
public:
	SmartPtr(T* ptr) : posptr(ptr) {};
	Point& operator*() const { return *posptr; }
	Point* operator->() const { return posptr; }
	~SmartPtr() { delete posptr; }
};

int main(void)
{
	SmartPtr<Point> sptr1(new Point(1, 2));
	SmartPtr<Point> sptr2(new Point(3, 4));

	sptr1->ShowPosition();
	sptr2->ShowPosition();

	sptr1->SetPos(10, 20);
	sptr2->SetPos(25, 32);

	sptr1->ShowPosition();
	sptr2->ShowPosition();

	int num = 3;

	return 0;
}