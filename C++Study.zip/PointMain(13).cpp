#include <iostream>
#include "PointTemplate(13).h"
#include "PointTemplate(13).cpp"
using namespace std;

int main(void)
{
	Point<int> pos1(1, 2);
	pos1.ShowPosition();
	return 0;
}